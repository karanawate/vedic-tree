<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require(APPPATH.'/libraries/REST_Controller.php');

class Studentprevious extends REST_Controller 
{
    
    public function index_post()
    {
         $student_id       = $this->input->post('student_id');
         $res = $this->teacherModel->student_previous_month($student_id);
         
         if(!empty($res)){
        
        	          $data = array('msg' => " data Successfully !",'res'=>$res,'code'=>200); 
        	          
        	    } else {
        	          
        	          $data = array('msg' => " Not Exist !",'res'=>$res,'code'=>404);
        	    }
        	    
        	    $this->response($data, REST_Controller::HTTP_OK);
    }
    
   

}

?>
